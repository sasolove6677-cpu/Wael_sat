# ستالايت — مشروع APK كامل

## المحتويات
- `app/src/main/assets/index.html` : صفحة ستالايت (v13).
- `MainActivity.kt` : WebView + جسر `SatBridge` (ترويسات القناة، كارت الالتقاط، حفظ الملفات) + اهتزاز `AccNative` + ملء الشاشة.
- `UvcActivity.kt` : شاشة كارت الالتقاط (UVC) عبر OTG.
- `gradlew` وملفات Gradle، وأيقونة، و`.github/workflows/build.yml` للبناء على GitHub.

## الرفع عبر MGit (من الموبايل)
1. فك الضغط في مجلد على هاتفك.
2. في GitHub أنشئ مستودعًا فارغًا، ثم أنشئ **Personal Access Token** (Settings ← Developer settings ← Tokens (classic) ← صلاحية `repo`).
3. في MGit: **Clone** للمستودع الفارغ (أو أنشئ Local repo)، وانسخ محتويات مجلد `Satellite` إلى مجلد المستودع (مع المجلد المخفي `.github`).
4. في MGit: **Stage all ← Commit ← Push** (اسم المستخدم = حسابك، كلمة المرور = الـ Token).
5. في GitHub افتح **Actions ← Build APK** (يعمل تلقائيًا بعد أول Push) ثم حمّل `satellite-apk` من الـ Artifacts.

## بعد التحديث
استبدل `app/src/main/assets/index.html` بأحدث نسخة ثم Commit و Push، وسيُبنى APK جديد.

## ملاحظات
- لم يُبنَ هذا المشروع في بيئتي (لا يوجد Android SDK)، فإن فشل البناء ألصق لي سجل Actions.
- مكتبة كارت الالتقاط (UVCAndroid) تأتي من JitPack وهي أول ما يُشتبه به عند أي فشل.
- التوقيع: debug (للتثبيت المباشر). للنشر في المتجر تحتاج مفتاح توقيع خاص.
