package com.satellite.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File

/** جسر صفحة ستالايت: ترويسات القناة الحالية + شاشة كارت الالتقاط + حفظ الملفات في التنزيلات */
class SatBridge(private val act: Activity? = null) {
    @Volatile var referer = ""; @Volatile var origin = ""; @Volatile var ua = ""

    @JavascriptInterface fun setHeaders(json: String) {
        try { val o = JSONObject(json); referer = o.optString("referer"); origin = o.optString("origin"); ua = o.optString("userAgent") }
        catch (_: Exception) { referer = ""; origin = ""; ua = "" }
    }

    @JavascriptInterface fun openUvc() {
        act?.runOnUiThread { act.startActivity(Intent(act, UvcActivity::class.java)) }
    }

    @JavascriptInterface fun saveText(name: String, mime: String, text: String): Boolean {
        val a = act ?: return false
        return try {
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = a.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
                a.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: return false
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs(); File(dir, safe).writeText(text, Charsets.UTF_8)
            }
            true
        } catch (_: Exception) { false }
    }
}

/** اهتزاز أصلي (نفس جسر برنامج المحاسبة) */
class AccNative(private val ctx: Context) {
    private val vib: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= 31) (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
    @JavascriptInterface fun vibrate(ms: Int) {
        val d = ms.coerceIn(1, 3000).toLong()
        if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE))
        else @Suppress("DEPRECATION") vib.vibrate(d)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: ViewGroup
    private val bridge = SatBridge(this)
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val http = OkHttpClient.Builder().followRedirects(true).followSslRedirects(true).build()
    private val mediaRe = Regex("""\.(m3u8|ts|m4s|mp4|aac|mpd|m4a)(\?|$)""", RegexOption.IGNORE_CASE)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // أذونات الكاميرا والمايك على مستوى النظام (مطلوبة لكارت الالتقاط)
        if (Build.VERSION.SDK_INT >= 23) {
            val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 7)
        }
        web = WebView(this)
        root = android.widget.FrameLayout(this).also { it.addView(web, ViewGroup.LayoutParams(-1, -1)) }
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true; allowFileAccessFromFileURLs = true; allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.addJavascriptInterface(bridge, "SatBridge")
        web.addJavascriptInterface(AccNative(this), "AccNative")

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = v; customCb = cb
                root.addView(v, ViewGroup.LayoutParams(-1, -1)); web.visibility = View.GONE
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }; customView = null
                web.visibility = View.VISIBLE; customCb?.onCustomViewHidden(); customCb = null
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val url = req.url.toString()
                if (req.method != "GET" || !url.startsWith("http") || !mediaRe.containsMatchIn(url)) return null
                if (bridge.referer.isEmpty() && bridge.origin.isEmpty() && bridge.ua.isEmpty()) return null
                val rb = Request.Builder().url(url)
                req.requestHeaders.forEach { (k, v) -> rb.header(k, v) }          // يشمل Range
                if (bridge.ua.isNotEmpty()) rb.header("User-Agent", bridge.ua)
                if (bridge.referer.isNotEmpty()) rb.header("Referer", bridge.referer)
                if (bridge.origin.isNotEmpty()) rb.header("Origin", bridge.origin)
                return try {
                    val r = http.newCall(rb.build()).execute()
                    val type = r.header("Content-Type")?.substringBefore(";") ?: "application/octet-stream"
                    val h = mutableMapOf("Access-Control-Allow-Origin" to "*")      // يحل CORS
                    r.headers.names().forEach { n -> if (!n.equals("content-encoding", true)) h[n] = r.header(n)!! }
                    WebResourceResponse(type, r.header("Content-Encoding"), r.code, r.message.ifEmpty { "OK" }, h, r.body?.byteStream())
                } catch (e: Exception) { null }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            else -> web.evaluateJavascript("(function(){try{return window.__satBack?window.__satBack():false}catch(e){return false}})()") { r ->
                if (r != "true") { if (web.canGoBack()) web.goBack() else finish() }
            }
        }
    }
}
